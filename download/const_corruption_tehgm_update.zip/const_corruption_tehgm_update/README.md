# const_corruption_tehgm_update
More black market traders are spawned gradually.

This version is fixed and tampered down. Over some time, 12% of the galaxy stations will have black market.

Original mod by Vectorial1024. Fix and rebalance update by TehGM.

Original version upload:
- Nexus Mods: https://www.nexusmods.com/x4foundations/mods/392
